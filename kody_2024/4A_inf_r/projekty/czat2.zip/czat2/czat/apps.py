from django.apps import AppConfig


class CzatConfig(AppConfig):
    name = 'czat'
